import React from "react";
import HeroBanner from "../Components/HeroBanner";

export default function HomePage() {
  return (
    <div className="home-page">
      <HeroBanner />
    </div>
  );
}
