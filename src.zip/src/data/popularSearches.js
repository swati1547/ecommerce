const popularSearches = [
  "Makeup",
  "Dresses For Girls",
  "T-Shirts",
  "Sandals",
  "Headphones",
  "Babydolls",
  "Blazers For Men",
  "Handbags",
  "Ladies Watches",
  "Bags",
  "Sport Shoes",
];
export default popularSearches;
