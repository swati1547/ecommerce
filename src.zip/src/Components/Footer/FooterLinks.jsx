import React from "react";

export default function FooterLinks() {
  return (
    <div>
      <div></div>
      <div></div>
      <div>
        <h6>EXPERIENCE MYNTRA APP ON MOBILE</h6>
        <h6>KEEP IN TOUCH</h6>
      </div>
      <div>
        <div>
          <p>
            <b>100% ORIGINAL</b> guarantee for all products at myntra.com
          </p>
        </div>
        <div>
          <p>Return within 14days of receiving your order</p>
        </div>
      </div>
    </div>
  );
}
