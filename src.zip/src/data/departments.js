const departments = [
  {
    _id: "dept_electronics",
    department_name: "MEN",
    slug: "electronics",
  },
  {
    _id: "dept_women",
    department_name: "WOMEN",
    slug: "women",
  },
  {
    _id: "dept_kids",
    department_name: "KIDS",
    slug: "women",
  },
  {
    _id: "dept_home",
    department_name: "HOME",
    slug: "women",
  },
  {
    _id: "dept_beauty",
    department_name: "BEAUTY",
    slug: "women",
  },
  {
    _id: "dept_genz",
    department_name: "GENZ",
    slug: "women",
  },
];

export default departments;
