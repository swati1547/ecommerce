import React from "react";

export default function CategoryLandingPage() {
  return <div>category</div>;
}
