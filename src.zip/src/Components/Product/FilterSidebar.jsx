import React from "react";

export default function FilterSidebar() {
  return <div></div>;
}
