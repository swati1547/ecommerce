import HomePage from "./Pages/HomePage";
import MainLayout from "./Pages/MainLayout";
import ProductInfo from "./Pages/ProductInfo";
import ProductListingPage from "./Pages/ProductListingPage";
import CategoryLandingPage from "./Pages/CategoryLandingPage";

const routes = [
  {
    element: <MainLayout />, // 👈 LAYOUT WRAPPER
    children: [
      {
        path: "/",
        element: <HomePage />,
      },
      {
        path: ":categorySlug/:subCategorySlug",
        element: <ProductListingPage />,
      },
      {
        path: "product/:productSlug/:productId",
        element: <ProductInfo />,
      },
      {
        path: ":categorySlug",
        element: <CategoryLandingPage />, // or ProductListingPage reuse
      },
      {
        path: "*",
        element: <p>Not Found</p>,
      },
    ],
  },
];

export default routes;
