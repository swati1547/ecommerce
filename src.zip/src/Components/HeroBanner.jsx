import React from "react";

export default function HeroBanner() {
  return (
    <div>
      <div className="token-container">
        <img
          className="token"
          src="src\assets\images\token.png"
          // width="100%"
        ></img>
      </div>

      <div>
        <img src="src\assets\images\heroImg.png" width="100%"></img>
      </div>
    </div>
  );
}
