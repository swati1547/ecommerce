import React, { useState } from "react";
import OfferPlans from "./OfferPlans";
import DeliveryOptions from "./DeliveryOptions";
import ProductData from "./ProductData";
import ActionButtons from "./ActionButtons";
import ProductIntro from "./ProductIntro";
import VarientSelector from "./VarientSelector";

export default function ProductInfoDetails({ product }) {
  const [selectedVariant, setSelectedVariant] = useState(null);

  return (
    <div className="pdp">
      <ProductIntro product={product} />
      <p className="pdp__heading">Select Size</p>
      <VarientSelector
        variants={product.variants}
        discount={product.discountPercentage}
        selectedVariant={selectedVariant}
        onSelect={setSelectedVariant}
      />
      <ActionButtons />
      <hr className="hr" />
      <DeliveryOptions />
      <OfferPlans />
      <ProductData product={product} />
    </div>
  );
}
