import React from "react";
import Navbar from "../Components/Navbar";
import BreadCrumb from "../Components/Product/BreadCrumb";
import { Outlet } from "react-router-dom";
import { useBreadcrumbContext } from "../context/BreadcrumbContext";
import Crash from "../Components/crash";

export default function MainLayout() {
  const { items } = useBreadcrumbContext();

  return (
    <div>
      {/* <Crash /> */}
      <Navbar />

      {/* content wrapper */}
      <main className="main-content" style={{ paddingTop: "80px" }}>
        <BreadCrumb items={items} />
        <Outlet />
      </main>
    </div>
  );
}
