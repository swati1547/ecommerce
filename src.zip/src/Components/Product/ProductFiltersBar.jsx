import React from "react";

export default function ProductFiltersBar() {
  return <div></div>;
}
